public class helloworld
{
  public static void main(String[] args) {
        System.out.println("Welcome to Hi-Tech Jenkins Training, Stay Safe.............");
 //creating object
  }
}
